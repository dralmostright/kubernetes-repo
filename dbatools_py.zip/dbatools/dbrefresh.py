from dbaconsole import dbaapp
app=dbaapp()
from dbaconsole import db
from dbaconsole.dbrefresh.models import Cdbtempalte

with app.app_context():
    db.drop_all()
    db.create_all()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "pga_aggregate_limit", "cdb_tpvalue":"0"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "control_file_record_keep_time", "cdb_tpvalue":"14"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "_system_trig_enabled", "cdb_tpvalue":"TRUE"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "enable_goldengate_replication", "cdb_tpvalue":"TRUE"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "processes", "cdb_tpvalue":"1200"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "pga_aggregate_target", "cdb_tpvalue":"8G"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "global_names", "cdb_tpvalue":"FALSE"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "filesystemio_options", "cdb_tpvalue":"'asynch'"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "log_archive_format", "cdb_tpvalue":"'%t_%s_%r.dbf'"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "db_files", "cdb_tpvalue":"999"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "remote_login_passwordfile", "cdb_tpvalue":"'EXCLUSIVE'"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_tname"], cdb_tpname=row["cdb_tpname"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "open_cursors", "cdb_tpvalue":"3200"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "_disk_sector_size_override", "cdb_tpvalue":"TRUE"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "session_cached_cursors", "cdb_tpvalue":"3200"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "recyclebin", "cdb_tpvalue":"'OFF'"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "undo_retention", "cdb_tpvalue":"1800"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "sga_target", "cdb_tpvalue":"8G"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "sga_max_size", "cdb_tpvalue":"8G"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "query_rewrite_enabled", "cdb_tpvalue":"'FALSE'"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()
    row={"cdb_ttype": "Oracle", "cdb_tname": "CDB_DEMO", "cdb_tpname" : "db_writer_processes", "cdb_tpvalue":"4"}
    template=Cdbtempalte(cdb_ttype=row["cdb_ttype"],cdb_tname=row["cdb_ttype"], cdb_tpname=row["cdb_ttype"],cdb_tpvalue=row["cdb_tpvalue"])
    db.session.add(template)
    db.session.commit()