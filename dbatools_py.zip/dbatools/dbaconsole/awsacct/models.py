from dbaconsole import db

class AWSACCOUNTS(db.Model):
    accountid = db.Column(db.Integer, primary_key=True)
    awsaccountid = db.Column(db.String(30), nullable=False)
    accountalias= db.Column(db.String(60), nullable=False)
    accountorg= db.Column(db.String(60), nullable=False)
    accesskeyid= db.Column(db.String(120), nullable=False)
    accountstatus= db.Column(db.String(10), nullable=False)
    secretaccesskey= db.Column(db.String(120), nullable=False) 
    
##AKIAWIINJS7AE4Q5AWUJ
##G8FfAj9CEUX6IF9La1GWvxpEX/eubCaQmDq0m0XU