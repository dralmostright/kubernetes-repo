from flask import render_template, Blueprint, flash, redirect, url_for, abort, request
from flask_login import current_user
from dbaconsole import db
from dbaconsole.awsacct.forms import AddAWSAccount,EditAWSAccount
from dbaconsole.awsacct.models import AWSACCOUNTS
import os
from dbaconsole.utils import encrypt,decrypt
from dbaconsole.config import Config
from dbaconsole.awsacct.utils import ValidateAccount

awsacct = Blueprint('awsacct', __name__)

##
##
##
@awsacct.route("/aws/addawsaccount", methods=['POST','GET'])
def addawsaccount():
    if current_user.is_authenticated:
        form=AddAWSAccount()
        form.accountstatus.choices = ['Select Status','Active','Disabled']    
        salt = os.urandom(16)
        secretkey=Config.SECRET_KEY
        
        if form.validate_on_submit():
            if form.accountstatus.data == 'Select Status':
                flash(f'Please select valid Status for Aws Account.','danger')
                return render_template('awsacct/add-aws-accounts.html', form=form, status='awsacc-addacc')
            awsaccount = AWSACCOUNTS(
            awsaccountid = form.awsaccountid.data,
            accountalias = form.accountalias.data,
            accountorg = form.accountorg.data,
            accountstatus = form.accountstatus.data,
            secretaccesskey = encrypt(form.secretaccesskey.data, secretkey, salt),
            accesskeyid = form.accesskeyid.data
            )
            db.session.add(awsaccount)
            db.session.commit()
            flash(f'AWS Account {form.awsaccountid.data} has been added Successfully.','success')
            return redirect(url_for('awsacct.listawsacc')) 
        else:
            return render_template('awsacct/add-aws-accounts.html', form=form, status='awsacc-addacc')   
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))
    
##
## Routes for Source database 
##
@awsacct.route("/aws/listawsacc", methods=['GET','POST'])
def listawsacc():
        if current_user.is_authenticated:
                srcdbs = AWSACCOUNTS.query.all()
                return render_template('awsacct/list-aws-accounts.html', status='awsacc-listacc',srcdbs=srcdbs)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login')) 
            
##
## Routes for edit Source database 
##
@awsacct.route("/aws/editawsacc/<int:accountid>",methods=['GET','POST'])
def editawsacc(accountid):
    if current_user.is_authenticated:
        form=EditAWSAccount()
        form.accountstatus.choices = ['Select Status','Active','Disabled']  
        data = AWSACCOUNTS.query.get_or_404(accountid)
        plainKey=decrypt(data.secretaccesskey, Config.SECRET_KEY)
        data.secretaccesskey=plainKey
        salt = os.urandom(16)
        secretkey=Config.SECRET_KEY
        if form.validate_on_submit():
                if ValidateAccount(accountid,form.awsaccountid.data):
                    flash(f'Configuration name '+form.awsaccountid.data+' already exists. Please try with new name.','danger')
                    return render_template('awsacct/edit-aws-accounts.html', form=form, status='awsacc-editacc',data=data) 
                data.awsaccountid = form.awsaccountid.data,
                data.accountalias = form.accountalias.data,
                data.accountorg = form.accountorg.data,
                data.accountstatus = form.accountstatus.data,
                data.secretaccesskey = encrypt(form.secretaccesskey.data, secretkey, salt),
                data.accesskeyid = form.accesskeyid.data
                db.session.commit()
                flash(f'Source Database Configuration for DB {form.awsaccountid.data} has been updated Successfully.','success')
                return redirect(url_for('awsacct.listawsacc')) 
        else:
                 return render_template('awsacct/edit-aws-accounts.html', form=form, status='awsacc-editawsacc',data=data)   
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login')) 