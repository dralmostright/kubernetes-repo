from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, PasswordField,SelectField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError
from dbaconsole import db
from dbaconsole.awsacct.models import AWSACCOUNTS
from wtforms_sqlalchemy.fields import QuerySelectField


class AddAWSAccount(FlaskForm):
    awsaccountid = StringField('Clone Database Template Name', validators=[DataRequired()])
    accountalias= StringField('Clone Database Template Name', validators=[DataRequired()])
    accountorg = StringField('Clone Database Template Name', validators=[DataRequired()])
    accesskeyid = StringField('Clone Database Template Name', validators=[DataRequired()])
    secretaccesskey = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    accountstatus = SelectField('Deleel')
    awsaddsubmit = SubmitField('Save Configuration')

    def validate_awsaccountid(self, awsaccountid):
        cdbtgtdb = AWSACCOUNTS.query.filter_by(awsaccountid=awsaccountid.data).first()
        if cdbtgtdb:
            raise ValidationError('Configuration name '+awsaccountid.data+' already exists. Please try with new name.')
    
        
class EditAWSAccount(FlaskForm):
    awsaccountid = StringField('Clone Database Template Name', validators=[DataRequired()])
    accountalias= StringField('Clone Database Template Name', validators=[DataRequired()])
    accountorg = StringField('Clone Database Template Name', validators=[DataRequired()])
    accesskeyid = StringField('Clone Database Template Name', validators=[DataRequired()])
    secretaccesskey = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    accountstatus = SelectField('Deleel')
    awsaddsubmit = SubmitField('Save Configuration')        