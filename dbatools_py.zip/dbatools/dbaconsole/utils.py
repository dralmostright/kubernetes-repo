import base64
import os
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import hashes

# Function to generate a key from a password and salt
def generate_key(password: str, salt: bytes) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,  # 32 bytes for AES-256
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return kdf.derive(password.encode())

# Function to encrypt a message
def encrypt(message: str, password: str, salt: bytes) -> str:
    key = generate_key(password, salt)

    # Generate a random IV (Initialization Vector)
    iv = os.urandom(16)

    # Pad the message to be a multiple of the block size
    padder = padding.PKCS7(128).padder()
    padded_message = padder.update(message.encode()) + padder.finalize()

    # Encrypt the message
    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    encrypted_message = encryptor.update(padded_message) + encryptor.finalize()

    # Return the encrypted message along with the salt and IV, encoded in base64 for easy storage
    return base64.b64encode(salt + iv + encrypted_message).decode()

# Function to decrypt a message
def decrypt(encrypted_message: str, password: str) -> str:
    decoded_data = base64.b64decode(encrypted_message)

    salt = decoded_data[:16]
    iv = decoded_data[16:32]
    encrypted_message = decoded_data[32:]

    key = generate_key(password, salt)

    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    padded_message = decryptor.update(encrypted_message) + decryptor.finalize()

    unpadder = padding.PKCS7(128).unpadder()
    original_message = unpadder.update(padded_message) + unpadder.finalize()

    return original_message.decode() 