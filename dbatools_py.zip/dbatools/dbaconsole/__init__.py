from flask import Flask
from flask import render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from dbaconsole.config import Config

db=SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'users.login'
login_manager.login_message_category = 'info'

def dbaapp(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(Config)

    @app.errorhandler(404) 
    # inbuilt function which takes error as parameter 
    def not_found(e): 
    # defining function 
        return render_template('pages-error-404.html')
    
    @app.errorhandler(500) 
    # inbuilt function which takes error as parameter 
    def internal_server_error(error): 
    # defining function 
        return render_template('page-error-custom.html'),500


    db.init_app(app)
    login_manager.init_app(app)

    from dbaconsole.users.routes import users
    from dbaconsole.main.routes import main
    from dbaconsole.dbrefresh.routes import dbrefresh
    from dbaconsole.awsacct.routes import awsacct
    from dbaconsole.awsrds.routes import awsrds
    app.register_blueprint(users)
    app.register_blueprint(main)
    app.register_blueprint(dbrefresh)
    app.register_blueprint(awsacct)
    app.register_blueprint(awsrds)

    return app