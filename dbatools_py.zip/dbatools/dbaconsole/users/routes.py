from flask import render_template, Blueprint, flash, redirect, url_for, abort
from flask_login import login_user, current_user, logout_user
from dbaconsole.users.forms import RegistrationForm, LoginForm
from dbaconsole.users.models import User
from dbaconsole import db
import os
from dbaconsole.config import Config
from dbaconsole.utils import encrypt,decrypt
from dbaconsole.main.models import ErrorTable

users = Blueprint('users', __name__)

@users.route("/login", methods=['GET','POST'])
def login():
    try:
        if current_user.is_authenticated:
            return redirect(url_for('main.home'))
        form=LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(email=form.email.data,status='Active').first()
            if user and decrypt(user.password, Config.SECRET_KEY) == form.password.data:
                login_user(user)
                return redirect(url_for('main.home'))
            else:
                flash(f'Invalid Credentials! Please try again.','danger')
                return redirect(url_for('users.login'))
        return render_template('users/login.html', form=form)    
    except Exception as e:
        #exception=ErrorTable(errorCurruser= current_user.email if user else "N/A",errorModule='Login',errorMessage=e)
        exception=ErrorTable(errorCurruser='None',errorModule='Login',errorMessage=str(e))
        db.session.add(exception)
        db.session.commit()
        abort(500)

@users.route("/register", methods=['GET','POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.home'))
    form=RegistrationForm()
    if form.validate_on_submit():
        salt = os.urandom(16)
        secretkey=Config.SECRET_KEY
        user=User(email=form.email.data, password=encrypt(form.password.data, secretkey, salt))
        db.session.add(user)
        db.session.commit()
        flash(f'{form.email.data} Account has been Created! Please login','success')
        return redirect(url_for('users.login'))
    return render_template('users/register.html', form=form)

@users.route("/logout")
def logout():
    logout_user()
    flash(f'You have successfully logout. Thank You!','success')
    return redirect(url_for('users.login'))

@users.route("/test")
def test():
    return render_template('home.html')