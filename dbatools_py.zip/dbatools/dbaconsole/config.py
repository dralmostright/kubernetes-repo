import os

class Config:
    SECRET_KEY = 'ABCDEF'
    #SECRET_KEY = os.environ.get('SECRET_KEY')
    # for sqlite
    #SQLALCHEMY_DATABASE_URI = 'sqlite:///../dbatoos.db'
    SQLALCHEMY_DATABASE_URI = "postgresql://postgres:postgres@192.168.227.128:5432/postgres"
    AWS_SERVER_PUBLIC_KEY='AKIAWIINJS7AE4Q5AWUJ'
    AWS_SERVER_SECRET_KEY='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'
    REGION_NAME='us-east-1'
    ##SQLALCHEMY_DATABASE_URI = 'mysql://root:mysql@localhost/dbatools'
    #SQLALCHEMY_DATABASE_URI = os.environ.get('SQLALCHEMY_DATABASE_URI')
    MAIL_SERVER = 'smtp.googlemail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('EMAIL_USER')
    MAIL_PASSWORD = os.environ.get('EMAIL_PASS')
    
    #import psycopg2
    #conn_string = "host='localhost' dbname='my_database' user='postgres' password='secret'"
    #conn = psycopg2.connect(conn_string)