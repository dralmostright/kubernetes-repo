from dbaconsole import db
from sqlalchemy import func

class ErrorTable(db.Model):
    errorid=db.Column(db.Integer, primary_key=True)
    errorCurruser= db.Column(db.String(120), nullable=True)
    errorModule=db.Column(db.String(100), nullable=True)
    errorMessage= db.Column(db.Text)
    errorDate = db.Column(db.DateTime, default=func.now())