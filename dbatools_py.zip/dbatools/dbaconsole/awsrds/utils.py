import boto3
from dbaconsole import db
from dbaconsole.awsacct.models import AWSACCOUNTS
from dbaconsole.awsrds.models import RDSINSTANCES
from dbaconsole.utils import decrypt
from dbaconsole.config import Config
import csv
from io import StringIO
from flask import Response
from datetime import datetime

def ListRDSInst(awsaccountID):
    query = db.session.query(AWSACCOUNTS, RDSINSTANCES).join(RDSINSTANCES, AWSACCOUNTS.awsaccountid == RDSINSTANCES.awsrdsdbacctid)
    query = query.filter(AWSACCOUNTS.accountstatus =='Active')
    if awsaccountID != "all":
        query = query.filter(RDSINSTANCES.awsrdsdbacctid==awsaccountID)
    data = query.all()
    awsInstances = AWSACCOUNTS.query.filter_by(accountstatus='Active').all() 
    return data,awsInstances


def ListDBInst(awsaccountID):
    if awsaccountID=='all':
        awsInstances = AWSACCOUNTS.query.filter_by(accountstatus='Active').all() 
    else:
        awsInstances = AWSACCOUNTS.query.filter_by(accountstatus='Active', awsaccountid=awsaccountID).all()   
        
    for awsInst in awsInstances:
        session = boto3.client(
            'rds',
            aws_access_key_id=awsInst.accesskeyid,
            aws_secret_access_key=decrypt(awsInst.secretaccesskey, Config.SECRET_KEY),
            region_name='us-east-1'
        )
        response = session.describe_db_instances()
        for rdsInst in response['DBInstances']:
            awsRDSInst = RDSINSTANCES(
            awsrdsdbacctid = awsInst.awsaccountid,
            awsrdsdbinstid = rdsInst['DBInstanceIdentifier'],
            awsrdsdbinstclass= rdsInst['DBInstanceClass'],
            awsrdsdbinstengine= rdsInst['Engine'],
            awsrdsdbinststatus= rdsInst['DBInstanceStatus'],
            awsrdsdbinstcreatetime= rdsInst['DBInstanceStatus'],
            awsrdsdbinstallocstorage=rdsInst['AllocatedStorage'],
            awsrdsdbazloc=rdsInst['AvailabilityZone'],
            awsrdsdblisencetype=rdsInst['LicenseModel'],
            awsrdsstoragetype=rdsInst['StorageType'],
            awsrdsmaxstorage=rdsInst['MaxAllocatedStorage']
            )
            db.session.add(awsRDSInst)
            db.session.commit()

    #print(allRDSInsts)
    #inst = SimpleNamespace(**allRDSInsts)
    
    ''' 
    for insts in allRDSInsts:
        print(insts.awsaccountid)
        print(insts.dbInstances)
    '''   
    #session = boto3.client(
    #'rds',
    #aws_access_key_id='AKIAWIINJS7AE4Q5AWUJ',
    #aws_secret_access_key='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',
    #region_name='us-east-1'
    #)
    #response = session.describe_db_instances()    
    #return response
    
def export_csv(awsaccountID, columnNames):
    # Create a string buffer to write CSV data into
    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=columnNames)
    
    query = db.session.query(AWSACCOUNTS, RDSINSTANCES).join(RDSINSTANCES, AWSACCOUNTS.awsaccountid == RDSINSTANCES.awsrdsdbacctid)
    query = query.filter(AWSACCOUNTS.accountstatus =='Active')
    if awsaccountID != "all":
        query = query.filter(RDSINSTANCES.awsrdsdbacctid==awsaccountID)
    data = query.all()
    
    # Write the header
    writer.writeheader()
    
    # Write the data rows
    for awsAcctdata,awsrdsList in data:
        writer.writerow(
            {
                "awsrdsdbacctid": awsrdsList.awsrdsdbacctid, 
                "awsrdsdbinstid": awsrdsList.awsrdsdbinstid, 
                "awsrdsdbinstengine": awsrdsList.awsrdsdbinstengine
            })
    
    # Get the CSV data as a string
    csv_data = output.getvalue()
    
    # Create a response to send the CSV file as a download
    now = datetime.now()
    formatted_date = now.strftime("%Y%m%d%H%M%S")
    filename="RDSInstanceList_"+formatted_date
    response = Response(csv_data, mimetype="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename="+filename+".csv"
    return response