from flask import render_template, Blueprint, flash, redirect, url_for, abort, request
from flask_login import login_user, current_user, logout_user
from dbaconsole import db
from dbaconsole.awsrds.utils import ListRDSInst,ListDBInst, export_csv
from dbaconsole.awsrds.models import RDSINSTANCES
from dbaconsole.utils import encrypt,decrypt

awsrds = Blueprint('awsrds', __name__)

@awsrds.route("/aws/rds/list/<acct>", methods=['GET','POST'])
@awsrds.route("/aws/rds/list", defaults={'acct': 'all'}, methods=['GET','POST'])
def listawsrds(acct):
    if current_user.is_authenticated:
        ListDBInst(acct)
        data,awsaccList=ListRDSInst(acct)
        return render_template('awsrds/list-aws-rds-inst.html', status='awsrds-listawsrds', data=data, awsaccList=awsaccList, acct=acct)
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login')) 
    
@awsrds.route("/aws/rds/export/<acct>", methods=['GET','POST'])
@awsrds.route("/aws/rds/export", defaults={'acct': 'all'}, methods=['GET','POST'])
def exportawsrds(acct):
    if current_user.is_authenticated:
        columnNames=['awsrdsdbacctid','awsrdsdbinstid','awsrdsdbinstengine']
        return export_csv(acct, columnNames)
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login')) 
        