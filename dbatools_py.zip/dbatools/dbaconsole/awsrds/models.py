from dbaconsole import db

class RDSINSTANCES(db.Model):
    awsrdsinstid=db.Column(db.Integer, primary_key=True)
    awsrdsdbacctid=db.Column(db.String(60), nullable=False)
    awsrdsdbinstid=db.Column(db.String(60), nullable=False)
    awsrdsdbinstclass=db.Column(db.String(30), nullable=False)
    awsrdsdbinstengine=db.Column(db.String(30), nullable=False)
    awsrdsdbinststatus=db.Column(db.String(30), nullable=False)
    awsrdsdbinstcreatetime=db.Column(db.String(30), nullable=False)
    awsrdsdbinstallocstorage=db.Column(db.String(30), nullable=False)
    awsrdsdbazloc=db.Column(db.String(30), nullable=False)
    awsrdsdblisencetype=db.Column(db.String(30), nullable=False)
    awsrdsstoragetype=db.Column(db.String(30), nullable=False)
    awsrdsmaxstorage=db.Column(db.String(30), nullable=False)