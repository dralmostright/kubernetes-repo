from flask import render_template, Blueprint, flash, redirect, url_for, abort, request
from flask_login import login_user, current_user, logout_user
from dbaconsole.dbrefresh.forms import CloneDBTeamplate,CloneEditDBTeamplate,\
                                CloneADDConfig,CloneADDZFSConfig,CloneEditZFSConfig,\
                                CloneSrcADDConfig, CloneSrcEditConfig, CloneTgtADDConfig,\
                                CloneTgtEditConfig, CloneMapConfig
from dbaconsole import db
from dbaconsole.dbrefresh.models import Cdbtempalte, CDBSRCDB, CDBZFSSRV, CDBTARGETDB, CDBMAPPING
from dbaconsole.dbrefresh.utils import SplitValues, ValidateSrcName ,ValidateTgtName,\
                                        popmapselect

dbrefresh = Blueprint('dbrefresh', __name__)

@dbrefresh.route("/addconfig", methods=['GET','POST'])
def addconfig():
        if current_user.is_authenticated:
                form = CloneADDConfig()
                if form.validate_on_submit():
                        srcdb = CDBSRCDB(
                                cdb_src_mstrname= form.cdb_src_mstrname.data,
                                cdb_src_dbname = form.cdb_src_dbname.data,
                                cdb_src_dbuname = form.cdb_src_dbuname.data,
                                cdb_src_dbhost = form.cdb_src_dbhost.data,
                                cdb_src_dbport = form.cdb_src_dbport.data,
                                cdb_src_dbservice = form.cdb_src_dbservice.data,
                                cdb_src_zfsmount = form.cdb_src_zfsmount.data,
                                cdb_src_dbuser = form.cdb_src_dbuser.data,
                                cdb_src_dbusrpwd = form.cdb_src_dbusrpwd.data
                        )
                        db.session.add(srcdb)
                        db.session.commit()
                return render_template('dbrefresh/addconfig.html', status='dbr-active', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listrdbs", methods=['GET','POST'])
def listrdbs():
        if current_user.is_authenticated:
                return render_template('dbrefresh/listrefdbs.html', status='dbr-list')
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/addvdbtem", methods=['GET','POST'])
def addvdbtem():
        if current_user.is_authenticated:
                form=CloneDBTeamplate()
                demoparams = Cdbtempalte.query.filter_by(cdb_tname='CDB_DEMO')
                if form.validate_on_submit():
                                flash(f'{form.cdb_tname.data} Init. Parameters Template has been Successfully created.','success')
                                parameters=SplitValues(form.cdb_parameter.data)
                                for x in range(len(parameters)):
                                        params=Cdbtempalte(cdb_ttype=form.cdb_ttype.data, 
                                                         cdb_tname=form.cdb_tname.data,
                                                         cdb_tpname=parameters[x-1][0],
                                                         cdb_tpvalue=parameters[x-1][1])
                                        db.session.add(params)
                                        db.session.commit()
                                return redirect(url_for('dbrefresh.editvdbtem', vdbtemplate=form.cdb_tname.data))
                else:
                        return render_template('dbrefresh/addvdbtemp.html',form=form, status='dbr-addtp',demoparams=demoparams)         
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listvdbtem", methods=['GET','POST'])
def listvdbtem():
        if current_user.is_authenticated:
                cdbtemplates = db.session.query(Cdbtempalte.cdb_tname).filter(Cdbtempalte.cdb_tname != 'CDB_DEMO').distinct().all()
                return render_template('dbrefresh/listvdbtemp.html', status='dbr-listtp',cdbtemplates=cdbtemplates)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))  

@dbrefresh.route("/editvdbtem/<string:vdbtemplate>",methods=['GET','POST'])
def editvdbtem(vdbtemplate):
        if current_user.is_authenticated:
                form=CloneEditDBTeamplate()
                demoparam = Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).first()
                if not demoparam:
                        abort(404)   
                demoparams = Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate) 
                form.cdb_tname.data=vdbtemplate;
                if form.validate_on_submit():
                        flash(f'{form.cdb_tname.data} Init. Parameters Template has been updated Successfully','success')
                        Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).delete()
                        db.session.commit()
                        parameters=SplitValues(form.cdb_parameter.data)
                        for x in range(len(parameters)):
                                if(len(parameters[x-1][0])> 0 and len(parameters[x-1][1]) > 0 ):
                                        params=Cdbtempalte(cdb_ttype=form.cdb_ttype.data, 
                                        cdb_tname=vdbtemplate,
                                        cdb_tpname=parameters[x-1][0],
                                        cdb_tpvalue=parameters[x-1][1])
                                        db.session.add(params)
                                        db.session.commit()
                        return redirect(url_for('dbrefresh.listvdbtem'))
                else:
                        return render_template('dbrefresh/editvdbtemp.html', form=form, status='dbr-edittp',demoparams=demoparams,demoparam=demoparam) 
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))  

@dbrefresh.route("/deletevdbtem/<string:vdbtemplate>",methods=['GET','POST'])
def deletevdbtem(vdbtemplate):
    if current_user.is_authenticated:
                demoparam = Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).first()
                if not demoparam:
                        abort(404) 
                Cdbtempalte.query.filter_by(cdb_tname=vdbtemplate).delete()
                db.session.commit()
                flash(f'{vdbtemplate} Init. Parameters Template has been deleted Successfully.','success')
                return redirect(url_for('dbrefresh.listvdbtem'))
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))    

@dbrefresh.route("/addzfssrv", methods=['GET','POST'])
def addzfssrv():
        if current_user.is_authenticated:
                form = CloneADDZFSConfig()
                if form.validate_on_submit():
                        zfs = CDBZFSSRV(
                                cdb_zfs_name= form.cdb_zfs_name.data,
                                cdb_zfs_host = form.cdb_zfs_host.data,
                                cdb_zfs_user = form.cdb_zfs_user.data,
                                cdb_zfs_password = form.cdb_zfs_password.data
                        )
                        db.session.add(zfs)
                        db.session.commit()
                        flash(f'{form.cdb_zfs_name.data} ZFS server details have saved successfully.','success')
                return render_template('dbrefresh/addzfssrv.html', status='dbr-addzfs', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

@dbrefresh.route("/listzfssrv", methods=['GET','POST'])
def listzfssrv():
        if current_user.is_authenticated:
                zfssrvs = CDBZFSSRV.query.all()
                return render_template('dbrefresh/listzfssrv.html', status='dbr-listzfs',zfssrvs=zfssrvs)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login')) 

@dbrefresh.route("/deletezfssrv/<int:cdb_zfs_id>",methods=['GET','POST'])
def deletezfssrv(cdb_zfs_id):
    if current_user.is_authenticated:
                demoparam = CDBZFSSRV.query.get_or_404(cdb_zfs_id)
                if demoparam:
                        CDBZFSSRV.query.filter_by(cdb_zfs_id=cdb_zfs_id).delete()
                        db.session.commit()
                        flash(f'{demoparam.cdb_zfs_name} ZFS Server details has been deleted Successfully.','success')
                        return redirect(url_for('dbrefresh.listzfssrv'))
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

@dbrefresh.route("/editzfssrv/<int:cdb_zfs_id>",methods=['GET','POST'])
def editzfssrv(cdb_zfs_id):
    if current_user.is_authenticated:
                form=CloneEditZFSConfig()
                zfssrv = CDBZFSSRV.query.filter_by(cdb_zfs_id=cdb_zfs_id).first()
                if not zfssrv:
                        abort(404) 
                return render_template('dbrefresh/editzfssrv.html', form=form, status='dbr-editzfs',zfssrv=zfssrv)
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

@dbrefresh.route("/savezfsform/<int:cdb_zfs_id>",methods=['GET','POST'])
def savezfsform(cdb_zfs_id):
    if current_user.is_authenticated:
        form=CloneEditZFSConfig()
        zfssrv = CDBZFSSRV.query.get_or_404(cdb_zfs_id)
        #zfssrv = CDBZFSSRV.query.filter_by(cdb_zfs_id=cdb_zfs_id).first()
        if form.validate_on_submit():
                zfssrv.cdb_zfs_name=form.cdb_zfs_name.data
                zfssrv.cdb_zfs_host=form.cdb_zfs_host.data
                zfssrv.cdb_zfs_user=form.cdb_zfs_user.data
                if not (form.cdb_zfs_password == ''):
                        zfssrv.cdb_zfs_password=form.cdb_zfs_password.data
                db.session.commit()
                flash(f'ZFS Server with id {cdb_zfs_id} has been updated Successfully.','success')
                return redirect(url_for('dbrefresh.listzfssrv')) 
        else:
                 return render_template('dbrefresh/editzfssrv.html', form=form, status='dbr-editzfs',zfssrv=zfssrv)   
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  


##
## Routes for Source database 
##
@dbrefresh.route("/addsrcdb", methods=['GET','POST'])
def addsrcdb():
        if current_user.is_authenticated:
                form = CloneSrcADDConfig()
                if form.validate_on_submit():
                        srcdb = CDBSRCDB(
                                cdb_src_dbname = form.cdb_src_dbname.data,
                                cdb_src_dbuname = form.cdb_src_dbuname.data,
                                cdb_src_dbhost = form.cdb_src_dbhost.data,
                                cdb_src_dbport = form.cdb_src_dbport.data,
                                cdb_src_dbservice = form.cdb_src_dbservice.data,
                                cdb_src_zfsmount = form.cdb_src_zfsmount.data,
                                cdb_src_dbuser = form.cdb_src_dbuser.data,
                                cdb_src_dbusrpwd = form.cdb_src_dbusrpwd.data,
                                cdb_src_zfsproject = form.cdb_src_zfsproject.data,
                                cdb_src_zfspool = form.cdb_src_zfspool.data,
                                cdb_src_zfsshare = form.cdb_src_zfsshare.data
                        )
                        db.session.add(srcdb)
                        db.session.commit()
                        flash(f'Database with name {form.cdb_src_dbname.data} has been added Successfully.','success')
                        return redirect(url_for('dbrefresh.listdbsrc')) 
                return render_template('dbrefresh/addsrcdbconfig.html', status='dbr-adddbsrc', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

##
## Routes for Source database 
##
@dbrefresh.route("/listdbsrc", methods=['GET','POST'])
def listdbsrc():
        if current_user.is_authenticated:
                srcdbs = CDBSRCDB.query.all()
                return render_template('dbrefresh/listdbsrc.html', status='dbr-listdbsrc',srcdbs=srcdbs)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login')) 

##
## Routes for edit Source database 
##
@dbrefresh.route("/editdbsrc/<int:cdb_src_id>",methods=['GET','POST'])
def editdbsrc(cdb_src_id):
    if current_user.is_authenticated:
        form=CloneSrcEditConfig()
        srcdb = CDBSRCDB.query.get_or_404(cdb_src_id)
        if form.validate_on_submit():
                if not ValidateSrcName(cdb_src_id,form.cdb_src_dbname.data):
                        flash(f'Configuration name '+form.cdb_src_dbname.data+' already exists. Please try with new name.','danger')
                        return render_template('dbrefresh/editdbsrc.html', form=form, status='dbr-editdbsrc',srcdb=srcdb) 
                srcdb.cdb_src_dbname = form.cdb_src_dbname.data
                srcdb.cdb_src_dbuname = form.cdb_src_dbuname.data
                srcdb.cdb_src_dbhost = form.cdb_src_dbhost.data
                srcdb.cdb_src_dbport = form.cdb_src_dbport.data
                srcdb.cdb_src_dbservice = form.cdb_src_dbservice.data
                srcdb.cdb_src_zfsmount = form.cdb_src_zfsmount.data
                srcdb.cdb_src_dbuser = form.cdb_src_dbuser.data
                srcdb.cdb_src_dbusrpwd = form.cdb_src_dbusrpwd.data
                srcdb.cdb_src_zfsproject = form.cdb_src_zfsproject.data
                srcdb.cdb_src_zfspool = form.cdb_src_zfspool.data
                srcdb.cdb_src_zfsshare = form.cdb_src_zfsshare.data
                db.session.commit()
                flash(f'Source Database Configuration for DB {form.cdb_src_dbname.data} has been updated Successfully.','success')
                return redirect(url_for('dbrefresh.listdbsrc')) 
        else:
                 return render_template('dbrefresh/editdbsrc.html', form=form, status='dbr-editdbsrc',srcdb=srcdb)   
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

##
## Routes for delete Source database 
##
@dbrefresh.route("/deletedbsrc/<int:cdb_src_id>",methods=['GET','POST'])
def deletedbsrc(cdb_src_id):
    if current_user.is_authenticated:
                srcdb = CDBSRCDB.query.get_or_404(cdb_src_id)
                if srcdb:
                        CDBSRCDB.query.filter_by(cdb_src_id=cdb_src_id).delete()
                        db.session.commit()
                        flash(f'{srcdb.cdb_src_dbname} Database Configuration details has been deleted Successfully.','success')
                        return redirect(url_for('dbrefresh.listdbsrc'))
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

##
## Routes for Traget Clone database 
##
@dbrefresh.route("/addtgtdb", methods=['GET','POST'])
def addtgtdb():
        if current_user.is_authenticated:
                form = CloneTgtADDConfig()
                if form.validate_on_submit():
                        tgtdb = CDBTARGETDB(
                                cdb_tgt_dbname = form.cdb_tgt_dbname.data,
                                cdb_tgt_dbunqname = form.cdb_tgt_dbunqname.data,
                                cdb_tgt_osuser = form.cdb_tgt_osuser.data,
                                cdb_tgt_osupwd = form.cdb_tgt_osupwd.data,
                                cdb_tgt_ohpath = form.cdb_tgt_ohpath.data,
                                cdb_tgt_dbhost = form.cdb_tgt_dbhost.data,
                                cdb_tgt_mount = form.cdb_tgt_mount.data,
                                cdb_tgt_zfsshare = form.cdb_tgt_zfsshare.data
                        )
                        db.session.add(tgtdb)
                        db.session.commit()
                        flash(f'Configuration for Clone Database with name {form.cdb_tgt_dbname.data} has been added Successfully.','success')
                        return redirect(url_for('dbrefresh.listdbtgt')) 
                return render_template('dbrefresh/addtgtdbconfig.html', status='dbr-addtgtdb', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))

##
## Routes for List Clone database 
##
@dbrefresh.route("/listdbtgt", methods=['GET','POST'])
def listdbtgt():
        if current_user.is_authenticated:
                tgtdbs = CDBTARGETDB.query.all()
                return render_template('dbrefresh/listdbtgt.html', status='dbr-listdbtgt',tgtdbs=tgtdbs)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login')) 

##
## Routes for edit Source database 
##
@dbrefresh.route("/editdbtgt/<int:cdb_tgt_id>",methods=['GET','POST'])
def editdbtgt(cdb_tgt_id):
    if current_user.is_authenticated:
        form=CloneTgtEditConfig()
        tgtdb = CDBTARGETDB.query.get_or_404(cdb_tgt_id)
        if form.validate_on_submit():
                if not ValidateTgtName(cdb_tgt_id,form.cdb_tgt_dbname.data):
                        flash(f'Configuration name '+form.cdb_tgt_dbname.data+' already exists. Please try with new name.','danger')
                        return render_template('dbrefresh/editdbtgt.html', form=form, status='dbr-editdbtgt',tgtdb=tgtdb) 
                tgtdb.cdb_tgt_dbname = form.cdb_tgt_dbname.data
                tgtdb.cdb_tgt_dbunqname = form.cdb_tgt_dbunqname.data
                tgtdb.cdb_tgt_osuser = form.cdb_tgt_osuser.data
                tgtdb.cdb_tgt_dbhost = form.cdb_tgt_dbhost.data
                tgtdb.cdb_tgt_osupwd = form.cdb_tgt_osupwd.data
                tgtdb.cdb_tgt_ohpath = form.cdb_tgt_ohpath.data
                tgtdb.cdb_tgt_mount = form.cdb_tgt_mount.data
                tgtdb.cdb_tgt_zfsshare = form.cdb_tgt_zfsshare.data
                db.session.commit()
                flash(f'Source Database Configuration for DB {form.cdb_tgt_dbname.data} has been updated Successfully.','success')
                return redirect(url_for('dbrefresh.listdbtgt')) 
        else:
                 return render_template('dbrefresh/editdbtgt.html', form=form, status='dbr-editdbtgt',tgtdb=tgtdb)   
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

##
## Routes for delete Source database 
##
@dbrefresh.route("/deletedbtgt/<int:cdb_tgt_id>",methods=['GET','POST'])
def deletedbtgt(cdb_tgt_id):
    if current_user.is_authenticated:
                tgtdb = CDBTARGETDB.query.get_or_404(cdb_tgt_id)
                if tgtdb:
                        CDBTARGETDB.query.filter_by(cdb_tgt_id=cdb_tgt_id).delete()
                        db.session.commit()
                        flash(f'{tgtdb.cdb_tgt_dbname} Clone Database Configuration details has been deleted Successfully.','success')
                        return redirect(url_for('dbrefresh.listdbtgt'))
    else:
        flash('Your must Login to access request page','info')
        return redirect(url_for('users.login'))  

@dbrefresh.route("/mapconfig", methods=['GET','POST'])
def mapconfig():
        if current_user.is_authenticated:
                form = CloneMapConfig()
                popmapselect(form)
                if form.validate_on_submit():
                        mapcon = CDBMAPPING(
                                cdb_map_name = form.cdb_map_name.data,
                                cdb_map_sdbid = form.cdb_map_sdbid.data,
                                cdb_map_tdbid = form.cdb_map_tdbid.data,
                                cdb_map_zfsid = form.cdb_map_zfsid.data,
                                cdb_map_dbtempid = form.cdb_map_dbtempid.data
                        )
                        db.session.add(mapcon)
                        db.session.commit()
                        flash(f'Configuration for Clone Database with name {form.cdb_map_name.data} has been added Successfully.','success')
                return render_template('dbrefresh/mapconfig.html', status='dbr-mapconfig', form=form)
        else:
                flash('Your must login to access request page!','info')
                return redirect(url_for('users.login'))