from dbaconsole import db

class Cdbtempalte(db.Model):
    cdb_tid = db.Column(db.Integer, primary_key=True)
    cdb_ttype= db.Column(db.String(120), nullable=True)
    cdb_tname= db.Column(db.String(60), nullable=False)
    cdb_tpname= db.Column(db.String(120), nullable=False)
    cdb_tpvalue = db.Column(db.String(120), nullable=False)

class CDBSRCDB(db.Model):
    cdb_src_id = db.Column(db.Integer, primary_key=True)
    cdb_src_dbname = db.Column(db.String(60))
    cdb_src_dbuname = db.Column(db.String(60), nullable=False)
    cdb_src_dbhost = db.Column(db.String(60), nullable=False)
    cdb_src_dbport = db.Column(db.String(10), nullable=False)
    cdb_src_dbservice = db.Column(db.String(60), nullable=False)
    cdb_src_zfsmount = db.Column(db.String(60), nullable=False)
    cdb_src_dbuser = db.Column(db.String(60), nullable=False)
    cdb_src_dbusrpwd = db.Column(db.String(60), nullable=False)
    cdb_src_zfsproject = db.Column(db.String(60), nullable=False)
    cdb_src_zfspool = db.Column(db.String(60), nullable=False)
    cdb_src_zfsshare = db.Column(db.String(60), nullable=False)

class CDBZFSSRV(db.Model):
    cdb_zfs_id = db.Column(db.Integer, primary_key=True)
    cdb_zfs_name = db.Column(db.String(60), nullable=False)
    cdb_zfs_host = db.Column(db.String(60), nullable=False)
    cdb_zfs_user = db.Column(db.String(60), nullable=False)
    cdb_zfs_password = db.Column(db.String(5), nullable=False)

class CDBTARGETDB(db.Model):
    cdb_tgt_id = db.Column(db.Integer, primary_key=True)
    cdb_tgt_dbname = db.Column(db.String(60), nullable=False)
    cdb_tgt_dbunqname = db.Column(db.String(60), nullable=False)
    cdb_tgt_osuser = db.Column(db.String(60), nullable=False)
    cdb_tgt_osupwd = db.Column(db.String(60), nullable=False)
    cdb_tgt_ohpath = db.Column(db.String(100), nullable=False)
    cdb_tgt_dbhost = db.Column(db.String(60), nullable=False)
    cdb_tgt_mount = db.Column(db.String(60), nullable=False)
    cdb_tgt_zfsshare = db.Column(db.String(60), nullable=False)

class CDBMAPPING(db.Model):
    cdb_map_id = db.Column(db.Integer, primary_key=True)
    cdb_map_name = db.Column(db.String(60), nullable=False)
    cdb_map_sdbid = db.Column(db.String(60), nullable=False)
    cdb_map_tdbid = db.Column(db.String(60), nullable=False)
    cdb_map_zfsid = db.Column(db.String(60), nullable=False)
    cdb_map_dbtempid = db.Column(db.String(60), nullable=False)
