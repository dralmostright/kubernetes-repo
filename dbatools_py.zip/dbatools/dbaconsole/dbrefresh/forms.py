from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, PasswordField,SelectField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError
from dbaconsole import db
from dbaconsole.dbrefresh.models import Cdbtempalte,CDBSRCDB,CDBZFSSRV,CDBTARGETDB, CDBMAPPING
from wtforms_sqlalchemy.fields import QuerySelectField

class SourceDB(FlaskForm):
    pass

class DestServer(FlaskForm):
    pass

class CloneDBTeamplate(FlaskForm):
    cdb_ttype = StringField('Database Type', validators=[DataRequired()])
    cdb_tname = StringField('Clone Database Template Name', validators=[DataRequired(),Length(min=4)])
    cdb_parameter = TextAreaField('Database Initializtion Parameters', validators=[DataRequired()])
    cdb_submit = SubmitField('Save Template')

    def validate_cdb_tname(self, cdb_tname):
        templatename = Cdbtempalte.query.filter_by(cdb_tname=cdb_tname.data).first()
        if templatename:
            raise ValidationError('A template with template name '+cdb_tname.data+' already exists. Please try with new name.')

class CloneEditDBTeamplate(FlaskForm):
    cdb_ttype = StringField('Database Type', validators=[DataRequired()])
    cdb_tname = StringField('Clone Database Template Name', validators=[DataRequired(),Length(min=4)])
    cdb_parameter = TextAreaField('Database Initializtion Parameters', validators=[DataRequired()])
    cdb_submit = SubmitField('Update Template')

class CloneADDConfig(FlaskForm):
    cdb_src_mstrname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbhost = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbport = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbservice = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsmount = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuser = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbusrpwd = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_project = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_pool = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_share = StringField('Clone Database Template Name', validators=[DataRequired()])

    def validate_cdb_src_mstrname(self, cdb_src_mstrname):
        cdbsrcdb = CDBSRCDB.query.filter_by(cdb_src_mstrname=cdb_src_mstrname.data).first()
        if cdbsrcdb:
            raise ValidationError('Configuration name '+cdb_src_mstrname.data+' already exists. Please try with new name.')

class CloneSrcADDConfig(FlaskForm):
    cdb_src_dbname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbhost = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbport = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbservice = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsmount = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuser = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbusrpwd = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsproject = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfspool = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsshare = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_submit = SubmitField('Save Configuration')

    def validate_cdb_src_dbname(self, cdb_src_dbname):
        cdbsrcdb = CDBSRCDB.query.filter_by(cdb_src_dbname=cdb_src_dbname.data).first()
        if cdbsrcdb:
            raise ValidationError('Configuration name '+cdb_src_dbname.data+' already exists. Please try with new name.')

class CloneSrcEditConfig(FlaskForm):
    cdb_src_dbname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbhost = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbport = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbservice = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsmount = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbuser = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_dbusrpwd = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsproject = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfspool = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_zfsshare = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_src_submit = SubmitField('Save Configuration')

class CloneADDZFSConfig(FlaskForm):
    cdb_zfs_name = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_host = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_user = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_password = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_submit = SubmitField('Save Configuration')

    def validate_cdb_zfs_name(self, cdb_zfs_name):
        cdbsrcdb = CDBZFSSRV.query.filter_by(cdb_zfs_name=cdb_zfs_name.data).first()
        if cdbsrcdb:
            raise ValidationError('Configuration name '+cdb_zfs_name.data+' already exists. Please try with new name.')

class CloneEditZFSConfig(FlaskForm):
    cdb_zfs_name = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_host = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_user = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_zfs_password = PasswordField('Clone Database Template Name')
    cdb_zfs_submit = SubmitField('Save Configuration')

    #def validate_cdb_zfs_name(self, cdb_zfs_name):
    #    cdbsrcdb = CDBZFSSRV.query.filter_by(cdb_zfs_name=cdb_zfs_name.data).first()
    #    if cdbsrcdb:
    #        raise ValidationError('Configuration name '+cdb_zfs_name.data+' already exists. Please try with new name.')

class CloneTgtADDConfig(FlaskForm):
    cdb_tgt_dbname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_dbunqname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_osuser = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_osupwd = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_ohpath = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_dbhost = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_mount = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_zfsshare = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_submit = SubmitField('Save Configuration')

    def validate_cdb_tgt_dbname(self, cdb_tgt_dbname):
        cdbtgtdb = CDBTARGETDB.query.filter_by(cdb_tgt_dbname=cdb_tgt_dbname.data).first()
        if cdbtgtdb:
            raise ValidationError('Configuration name '+cdb_tgt_dbname.data+' already exists. Please try with new name.')

class CloneTgtEditConfig(FlaskForm):
    cdb_tgt_dbname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_dbunqname = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_osuser = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_osupwd = PasswordField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_ohpath = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_dbhost = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_mount = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_zfsshare = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_tgt_submit = SubmitField('Save Configuration')

class CloneMapConfig(FlaskForm):
    cdb_map_name = StringField('Clone Database Template Name', validators=[DataRequired()])
    cdb_map_sdbid= SelectField('Deleel', coerce=int)
    cdb_map_tdbid = SelectField('Deleel', coerce=int)
    cdb_map_zfsid = SelectField('Deleel', coerce=int)
    cdb_map_dbtempid = SelectField('Deleel')
    cdb_map_submit = SubmitField('Save Configuration')

    def validate_cdb_map_name(self, cdb_map_name):
        cdbtgtdb = CDBMAPPING.query.filter_by(cdb_map_name=cdb_map_name.data).first()
        if cdbtgtdb:
            raise ValidationError('Configuration name '+cdb_map_name.data+' already exists. Please try with new name.')