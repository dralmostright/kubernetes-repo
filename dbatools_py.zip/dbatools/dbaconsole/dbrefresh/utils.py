from dbaconsole.dbrefresh.models import CDBSRCDB, CDBTARGETDB, CDBZFSSRV, \
                                        Cdbtempalte
from dbaconsole import db

def ValidateSrcName(cdb_src_id,cdb_src_dbname):
    cdbsrcdb = CDBSRCDB.query.filter_by(cdb_src_dbname=cdb_src_dbname).first()
    if (cdbsrcdb):
        if (cdbsrcdb.cdb_src_id==cdb_src_id):
            return True
        else:
            return False
    else:
        return True

def ValidateTgtName(cdb_tgt_id,cdb_tgt_dbname):
    cdbtgtdb = CDBTARGETDB.query.filter_by(cdb_tgt_dbname=cdb_tgt_dbname).first()
    if (cdbtgtdb):
        if (cdbtgtdb.cdb_tgt_id==cdb_tgt_id):
            return True
        else:
            return False
    else:
        return True

def SplitValues (text):
    values = []
    textsplit = text.strip().split('\n')
    for txt in textsplit:
        val=txt.rstrip().split('=')
        values.append(val)
    return values

def convertTolist(listinput):
    stagelists = []
    stagelist = []
    for i in list(listinput):
        stagelist.append(i[0])
        stagelist.append(i[1])
        stagelists.append(stagelist)
        stagelist=[]
    return stagelists

def popmapselect(form):
    srcdb=db.session.query(CDBSRCDB.cdb_src_id, CDBSRCDB.cdb_src_dbname).all()
    zfssrv=db.session.query(CDBZFSSRV.cdb_zfs_id, CDBZFSSRV.cdb_zfs_name).all()
    tardb=db.session.query(CDBTARGETDB.cdb_tgt_id, CDBTARGETDB.cdb_tgt_dbname).all()
    inittempl=db.session.query(Cdbtempalte.cdb_tname,Cdbtempalte.cdb_tname).filter(Cdbtempalte.cdb_tname != 'CDB_DEMO')\
                .distinct().all()
    form.cdb_map_sdbid.choices = convertTolist(srcdb)
    form.cdb_map_zfsid.choices = convertTolist(zfssrv)
    form.cdb_map_tdbid.choices = convertTolist(tardb)
    form.cdb_map_dbtempid.choices = convertTolist(inittempl)