from dbaconsole import dbaapp

app = dbaapp()

if __name__ == '__main__':
    app.run(debug=True)
    
    